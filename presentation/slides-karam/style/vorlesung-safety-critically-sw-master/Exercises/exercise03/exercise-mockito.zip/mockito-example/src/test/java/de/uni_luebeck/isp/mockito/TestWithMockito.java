package de.uni_luebeck.isp.mockito;

import static org.mockito.Mockito.*;
/**
 * Test suite using Mockito to generate mock objects.
 * 
 * @author INSERT YOUR NAME HERE
 *
 */
public class TestWithMockito {
	// TODO Add JUnit test cases
}
