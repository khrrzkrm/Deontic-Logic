package de.uni_luebeck.isp.mockito;

import static org.junit.Assert.*;

/**
 * Test suite using a mock class written manually.
 * 
 * @author INSERT YOUR NAME HERE
 *
 */
public class TestWithManualMockup {
	// TODO Write JUnit test cases
}
